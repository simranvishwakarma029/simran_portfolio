
// export default function Experience() {
//   return (
//     <section id="experience" className="section">
//       <div className="container">
//         <h2 className="text-3xl md:text-4xl font-bold mb-8">Experience</h2>
//         <div className="grid gap-6">
//           <div className="card p-6">
//             <div className="flex items-center justify-between">
//               <h3 className="font-semibold">Frontend Developer — Yash Soft Solution</h3>
//               <span className="text-sm text-slate-400">6 months</span>
//             </div>
//             <p className="mt-2 text-slate-300 text-sm">
//               Worked with React, Bootstrap, and Sass to build responsive interfaces and reusable components.
//             </p>
//           </div>
//         </div>
//       </div>
//     </section>
//   );
// }
